const mongoose = require('mongoose');

// User Schema
const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, required: true, enum: ['Employer', 'Job Seeker'] },
  phone: { type: String },
});

const User = mongoose.model('User', userSchema);

// Job Schema
const jobSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  category: { type: String, required: true },
  country: { type: String, required: true },
  city: { type: String, required: true },
  location: { type: String, required: true },
  salaryFrom: { type: Number },
  salaryTo: { type: Number },
  fixedSalary: { type: Number },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
});

const Job = mongoose.model('Job', jobSchema);

module.exports = { User, Job };